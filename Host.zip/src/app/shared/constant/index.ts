import { MAIN } from './main';
import { ENV } from './env';

export const CONSTANTS = {
    MAIN,
    ENV
};

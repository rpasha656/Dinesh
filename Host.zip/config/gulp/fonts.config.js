module.exports = [
    'node_modules/font-awesome/fonts/*.*',
    'node_modules/bootstrap-sass/assets/fonts/bootstrap/*.*'
];